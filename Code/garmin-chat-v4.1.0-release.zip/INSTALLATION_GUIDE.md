# Installation Guide - Garmin Chat Desktop v4.1.0

## Quick Start

### For Most Users (Recommended)

1. **Download the Installer**
   - Get `GarminChatSetup.exe` from the [Releases page](../../releases/latest)
   - File size: ~50 MB

2. **Run the Installer**
   - Double-click `GarminChatSetup.exe`
   - If Windows SmartScreen appears, click "More info" → "Run anyway"
   - Follow the installation wizard

3. **Choose Installation Location**
   - Default: `C:\Program Files\Garmin Chat Desktop\`
   - Or choose custom location

4. **Complete Installation**
   - Click "Install"
   - Wait for files to extract (~1 minute)
   - Click "Finish"

5. **Launch**
   - Find "Garmin Chat" in your Start menu
   - Or use the desktop shortcut (if created)

## Initial Setup

### First Launch

When you first open Garmin Chat Desktop, you'll be prompted to configure:

#### 1. Garmin Connect Credentials
- **Email**: Your Garmin Connect email
- **Password**: Your Garmin Connect password
- These are stored securely on your local machine only

#### 2. Choose AI Provider

You have two main options:

**Option A: Free & Private (Ollama - Recommended)**
- No API costs
- Complete privacy
- Works offline
- Requires separate Ollama installation
- See [Ollama Setup Guide](OLLAMA_SETUP_GUIDE.md)

**Option B: Cloud AI (Pay-per-use)**
- xAI, OpenAI, Gemini, Claude, or Azure
- Requires API key
- Typically costs $1-5/month for casual use
- See "API Key Setup" below

#### 3. Connect and Start Chatting
- Click "Connect to Garmin"
- Wait for data to sync (~10-30 seconds)
- Start asking questions about your fitness data!

## Ollama Setup (For Free, Local AI)

### Why Choose Ollama?
- ✅ **$0 forever** - No subscription or API costs
- ✅ **100% private** - Data never leaves your computer
- ✅ **Works offline** - No internet needed after setup
- ✅ **Unlimited** - Ask as many questions as you want

### Installation Steps

1. **Install Ollama**
   - **Windows**: Download from https://ollama.com/download/windows
   - **Mac**: Download from https://ollama.com/download/mac
   - **Linux**: Run `curl -fsSL https://ollama.com/install.sh | sh`

2. **Pull a Model** (in terminal/command prompt)
   ```bash
   # Recommended for most users (fast, efficient)
   ollama pull llama2

   # Or for better quality
   ollama pull llama3.2

   # Or for maximum quality (requires 16GB+ RAM)
   ollama pull llama3.1:70b
   ```

3. **Configure Garmin Chat**
   - Open Garmin Chat Desktop
   - Click Settings (⚙️)
   - Select "Ollama (Local)" as AI Provider
   - Endpoint should auto-fill: `http://localhost:11434`
   - Click "Test Connection"
   - Select your model from dropdown
   - Click "Save"

4. **Verify**
   - You should see "✓ Connected successfully" message
   - Your model will appear in the dropdown
   - Close settings and start chatting!

For detailed Ollama setup, see [OLLAMA_SETUP_GUIDE.md](OLLAMA_SETUP_GUIDE.md).

## API Key Setup (For Cloud AI)

### xAI (Grok)
1. Visit https://console.x.ai/
2. Sign up or log in
3. Navigate to API Keys
4. Click "Create new API key"
5. Copy the key
6. Paste into Garmin Chat Settings → xAI API Key

**Cost**: Pay-per-use, typically $1-3/month for casual use

### OpenAI (ChatGPT)
1. Visit https://platform.openai.com/api-keys
2. Sign in or create account
3. Click "Create new secret key"
4. Name your key (e.g., "Garmin Chat")
5. Copy the key (you won't see it again!)
6. Paste into Garmin Chat Settings → OpenAI API Key

**Cost**: Pay-per-use, ~$0.01 per conversation

### Google Gemini
1. Visit https://makersuite.google.com/app/apikey
2. Sign in with Google account
3. Click "Create API key"
4. Select or create a Google Cloud project
5. Copy the key
6. Paste into Garmin Chat Settings → Gemini API Key

**Cost**: Free tier available, then pay-per-use

### Anthropic (Claude)
1. Visit https://console.anthropic.com/
2. Create account or sign in
3. Go to API Keys section
4. Click "Create Key"
5. Name your key
6. Copy the key
7. Paste into Garmin Chat Settings → Anthropic API Key

**Cost**: Pay-per-use, competitive with OpenAI

### Azure OpenAI
1. Set up Azure OpenAI service in Azure Portal
2. Deploy a model (e.g., GPT-4)
3. Get your endpoint URL and API key
4. In Garmin Chat Settings:
   - Enter Azure Endpoint (e.g., `https://your-resource.openai.azure.com/`)
   - Enter Deployment Name
   - Enter API Key

**Cost**: Enterprise pricing, varies by deployment

## System Requirements

### Minimum Requirements
- **OS**: Windows 10 (64-bit) or Windows 11
- **RAM**: 4GB
- **Storage**: 200MB for application
- **Internet**: Required for cloud AI providers

### Recommended for Ollama
- **RAM**: 8GB+ (16GB for larger models)
- **Storage**: Additional 2-40GB for models
- **Processor**: Modern CPU (2015 or newer)
- **GPU**: Optional but recommended for faster inference

### Model Size Guide
| Model | Size | RAM Needed | Speed | Quality |
|-------|------|------------|-------|---------|
| llama2 | 3.8GB | 8GB | Fast | Good |
| llama3.2 | 2.0GB | 8GB | Fast | Excellent |
| mistral | 4.1GB | 8GB | Fast | Very Good |
| llama3.1:13b | 7.4GB | 16GB | Medium | Excellent |
| llama3.1:70b | 40GB | 32GB+ | Slow | Best |

## Uninstallation

### Windows
1. Go to Settings → Apps → Installed apps
2. Find "Garmin Chat Desktop"
3. Click three dots → Uninstall
4. Follow the prompts

### Manual Cleanup (Optional)
Configuration and chat history are stored in:
```
C:\Users\YourUsername\.garmin_chat\
```

Delete this folder to remove all data and settings.

## Troubleshooting Installation

### "Windows protected your PC" SmartScreen Warning
This is normal for new applications. Click "More info" → "Run anyway"

### Installation Fails
- Run installer as Administrator (right-click → Run as administrator)
- Temporarily disable antivirus
- Ensure you have write permissions to installation directory

### Application Won't Start
1. Check Windows Event Viewer for error details
2. Verify all installation files are present
3. Try reinstalling
4. Check that you have .NET Framework 4.7.2+ installed

### Ollama Connection Issues
See detailed troubleshooting in [OLLAMA_SETUP_GUIDE.md](OLLAMA_SETUP_GUIDE.md)

## Updating

### Automatic Update Check
Garmin Chat Desktop will notify you when updates are available.

### Manual Update
1. Download latest installer from Releases page
2. Run installer - it will update your existing installation
3. Your settings and chat history are preserved

## Portable Installation

To run without installing:
1. Download source code
2. Install Python 3.11+
3. Install dependencies: `pip install -r requirements.txt`
4. Run: `python GarminChatDesktop.py`

## Building from Source

See [BUILD.md](BUILD.md) for developer instructions.

## Getting Help

- **Documentation**: [README.md](README.md)
- **Ollama Setup**: [OLLAMA_SETUP_GUIDE.md](OLLAMA_SETUP_GUIDE.md)
- **Issues**: [GitHub Issues](../../issues)
- **Discussions**: [GitHub Discussions](../../discussions)

---

**Enjoy using Garmin Chat Desktop!** 🎉
