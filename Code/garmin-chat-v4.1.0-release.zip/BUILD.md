# Build Instructions for Garmin Chat Desktop v4.1.0

This guide covers building the Windows executable and installer from source.

## Prerequisites

### Required Software
- **Python 3.11 or 3.12** (64-bit)
- **PyInstaller** 6.11.1+
- **Inno Setup** 6.x (for creating installer)
- **Git** (optional, for version control)

### Install Python Dependencies
```bash
pip install -r requirements.txt
```

## Build Steps

### Step 1: Prepare Files

Ensure you have these files in your project directory:
```
GarminChatDesktop/
├── GarminChatDesktop.py
├── ai_client.py
├── garmin_handler.py
├── logo.ico
├── logo.png
├── requirements.txt
├── README.md
├── CHANGELOG.md
├── INSTALLATION_GUIDE.md
├── OLLAMA_SETUP_GUIDE.md
└── RELEASE_NOTES_v4.1.0.md
```

### Step 2: Create/Verify PyInstaller Spec File

Create `GarminChatDesktop.spec`:

```python
# -*- mode: python ; coding: utf-8 -*-

block_cipher = None

a = Analysis(
    ['GarminChatDesktop.py'],
    pathex=[],
    binaries=[],
    datas=[
        ('logo.ico', '.'),
        ('logo.png', '.'),
    ],
    hiddenimports=[
        'garth',
        'openai',
        'anthropic',
        'google.genai',
        'google.genai.types',
        'requests',
        'docx',
        'reportlab',
        'PIL',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        'pytest',
        'pytest-cov',
        'hypothesis',
        'unittest',
        'test',
        'tests',
        '_pytest',
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='GarminChatDesktop',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,  # No console window
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon='logo.ico',
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='GarminChatDesktop',
)
```

### Step 3: Build Executable

```bash
# Clean previous builds
rmdir /s /q build dist

# Build with PyInstaller
pyinstaller GarminChatDesktop.spec

# Output will be in: dist/GarminChatDesktop/
```

### Step 4: Test the Executable

```bash
cd dist\GarminChatDesktop
GarminChatDesktop.exe
```

Verify:
- Application starts without errors
- Logo and icons display correctly
- Can connect to Garmin
- Can select AI providers
- Ollama connection test works (if Ollama installed)
- All features functional

### Step 5: Create Installer with Inno Setup

Create `installer_script.iss`:

```ini
#define MyAppName "Garmin Chat Desktop"
#define MyAppVersion "4.1.0"
#define MyAppPublisher "Your Name"
#define MyAppURL "https://github.com/yourusername/garmin-chat-desktop"
#define MyAppExeName "GarminChatDesktop.exe"

[Setup]
AppId={{YOUR-GUID-HERE}}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}/issues
AppUpdatesURL={#MyAppURL}/releases
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
AllowNoIcons=yes
LicenseFile=LICENSE.txt
OutputDir=.
OutputBaseFilename=GarminChatSetup
SetupIconFile=logo.ico
Compression=lzma
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Files]
Source: "dist\GarminChatDesktop\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "README.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "CHANGELOG.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "INSTALLATION_GUIDE.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "OLLAMA_SETUP_GUIDE.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "LICENSE.txt"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\{cm:UninstallProgram,{#MyAppName}}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Name: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,{#StringChange(MyAppName, '&', '&&')}}"; Flags: nowait postinstall skipifsilent
```

### Step 6: Compile Installer

```bash
# Right-click installer_script.iss → Compile with Inno Setup
# Or from command line:
"C:\Program Files (x86)\Inno Setup 6\ISCC.exe" installer_script.iss

# Output: GarminChatSetup.exe
```

### Step 7: Test Installer

1. Run `GarminChatSetup.exe`
2. Install to default location
3. Verify shortcuts created
4. Launch application
5. Test all features
6. Uninstall and verify clean removal

## Build Optimization

### Reducing Executable Size

Edit `GarminChatDesktop.spec` to exclude unnecessary modules:

```python
excludes=[
    # Test frameworks
    'pytest', 'pytest-cov', 'hypothesis', 'unittest', 'test', 'tests',
    # Unused stdlib modules
    'pydoc', 'doctest', 'xmlrpc', 'pdb', 'profile', 'cProfile',
    # Large unused dependencies
    'matplotlib', 'numpy', 'pandas', 'scipy',
],
```

### UPX Compression

PyInstaller uses UPX by default. To disable (faster build, larger size):

```python
exe = EXE(
    # ...
    upx=False,  # Disable UPX
    # ...
)
```

## Troubleshooting Build Issues

### "Module not found" Error
```bash
# Add to hiddenimports in .spec file
hiddenimports=['missing_module_name'],
```

### Icon Not Showing
- Verify `logo.ico` exists and is valid Windows ICO format
- Check `datas` section includes icon
- Rebuild from clean state

### Application Crashes on Startup
- Test in console mode first: `console=True` in .spec
- Check for missing dependencies in hiddenimports
- Verify Python version compatibility (3.11-3.12)

### Large Executable Size
- Review excludes list
- Check for accidentally included test files
- Verify UPX is enabled

## Version Control

### Git Tag for Release
```bash
git tag -a v4.1.0 -m "Release v4.1.0 - Ollama Support"
git push origin v4.1.0
```

## Release Checklist

- [ ] Update version in `GarminChatDesktop.py` (line 7)
- [ ] Update CHANGELOG.md
- [ ] Update README.md with new features
- [ ] Create RELEASE_NOTES_v4.1.0.md
- [ ] Test all AI providers
- [ ] Test Ollama integration
- [ ] Clean build (`rmdir /s /q build dist`)
- [ ] Build executable with PyInstaller
- [ ] Test executable on clean Windows machine
- [ ] Build installer with Inno Setup
- [ ] Test installer
- [ ] Calculate SHA256 checksum
- [ ] Create GitHub release
- [ ] Upload installer
- [ ] Update release notes with checksum
- [ ] Announce release

## File Checksums

After building, generate SHA256 checksum:

```powershell
# PowerShell
Get-FileHash GarminChatSetup.exe -Algorithm SHA256
```

```bash
# Linux/Mac
sha256sum GarminChatSetup.exe
```

Add checksum to release notes.

## Distribution

### GitHub Release
1. Go to repository → Releases → Draft new release
2. Tag: `v4.1.0`
3. Title: "Garmin Chat Desktop v4.1.0 - Ollama Support"
4. Description: Paste RELEASE_NOTES_v4.1.0.md
5. Attach `GarminChatSetup.exe`
6. Add SHA256 checksum
7. Mark as latest release
8. Publish

### File Sharing
- **GitHub Releases**: Primary distribution
- **Direct Download**: Link to GitHub release
- **Alternative Mirrors**: Consider for redundancy

## Support

For build issues:
- Check this guide
- Review PyInstaller documentation
- Check Inno Setup documentation
- Report issues on GitHub

---

**Build Time**: Approximately 2-5 minutes on modern hardware
**Installer Size**: ~50 MB
**Supported OS**: Windows 10/11 (64-bit)
